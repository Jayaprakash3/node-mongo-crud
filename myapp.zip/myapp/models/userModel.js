const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const userSchema = new mongoose.Schema({

    id: ObjectId,
    name: String,
    username: String,
    email: String,
    department: String,
    college: String
});

const userModel = mongoose.model('user', userSchema);

function model() {
    return userModel;
}

function createUser(params) {
    return new Promise((resolve, reject) => {


        userModel.create(params).then((data) => {
            resolve(data);
        }).catch((error) => {
            reject(error)
        });
    });

}
function create(request) {
    return new Promise((resolve, reject) => {
        request.save().then((response) => {
            resolve(response);
        }).catch((err) => {
            reject(err);
        })
    });
}

module.exports = {
    createUser,
    create,
    model
};