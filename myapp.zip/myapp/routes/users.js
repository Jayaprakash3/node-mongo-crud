var express = require('express');
var router = express.Router();

router.post('/createNewUser', async function (req, res) {
  var params = req.body;
  console.log(params)
  await userModel.createUser(params).then(async (userObj) => {
    if (userObj) {
      // res.status(200).send({
      //   user: userData
      // })
      var postReq = {
        title: params.title,
        body1: params.body1,
        userId: userObj._id
      }
      await postModel.createPost(postReq).then((postData) => {
        var result = {
          message: "User & Post saved successfully.",
          userData: userData,
          postData: postData
        }

        console.log(result)
        res.status(200).send({
          result
        })
      }).catch((error) => {
        console.log()
        res.status(403).send({
          message: "Post creation Failed",
          data: error
        })
      })
    } else {
      res.status(403).send({
        message: "Databse Error"
      })
    }
  }).catch((error) => {
    res.status(403).send({
      message: "User data not found",
      data: error
    })

  })

});

module.exports = router;
